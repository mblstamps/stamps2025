library(ape)
library(ggtree)

#Replace below the name of the output of the tree you are interested in visualizing
name_of_output <- "PF02410-tree-output" 

output_tree <- read.tree(paste(name_of_output,"/",name_of_output,".tre",sep = ""))


#Just a sanity check, we are seeing how 
output_tree$tip.label
length(output_tree$tip.label)

#Code to visualize the tree
# Change values inside the xlim(,) argument to make sure labels are fully visible

tree_plot <- ggtree(output_tree) + 
  geom_tiplab() + #To add the leaf labels
  theme_tree2() + #This adds measurements at the bottom of the plot
  xlim(0, 1.4)    #This changes the size of the figure on the x-axis
tree_plot

#Alternatively, if we do not care about branch length

tree_plot <- ggtree(output_tree, branch.length = "none") + 
  theme_tree2() + 
  geom_tiplab() + 
  xlim(0, 10)
tree_plot 
